function get_yacin(url) {
    get_yacin_res(url, function (res) {
        console.log(res);
    });
}
$("#open_aflam_w_muslslat").click(function () {
    $(`[data-full_iframe_target_url="movies.html"]`).parents("li").click();
})
$("#open_gdwal_elmobrayat").click(function () {
    $(`[data-full_iframe_target_url="matches_table.html"]`).parents("li").click();
});
$("#open_channels").click(function () {
    $(`[data-full_iframe_target_url="chnnels.html"]`).parents("li").click();
});
$("[data-open_server]").click(function () {
    server_name = $(this).attr("data-open_server");
    server_url = "movies.html?film_server_name=" + server_name;
    open_film_on_iframe("#servers_frame", server_url);
});

// $("#home_ad").html(get_ad_iframe());
// $('[data-full_iframe_target_url="matches_table.html"]').click();

window.addEventListener('resize', resize_text, true);
function resize_text() {
    var text_class = "mou_resize_text";
    var text_size = 8;
    elmnt = $("." + text_class);

    $(elmnt).each(function () {
        text_size = parseInt($(this).attr("data-textsize"));
        elmnt_width = $(this).parent().width();
        new_text_size = text_size / 100 * elmnt_width;
        $(this)[0].style.setProperty('font-size', new_text_size + "px", 'important');
    });

}
$(document).ready(function () {
    $(".preloader").css("display", "none");
    $(".home_posts_container").css("display", "block");
    resize_text();

});

function open_matches_table() {
    $(`[data-full_iframe_target_url="matches_table.html"]`).click();
}
function open_channels() {
    $(`[data-full_iframe_target_url="chnnels.html"]`).click();
}