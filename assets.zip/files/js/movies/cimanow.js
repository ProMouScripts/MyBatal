obj = {
    "main_domain": "https://bs.cimanow.cc/",
    "server_domain": "https://bs.cimanow.cc/",
    "working_state": true,
    "type": "cats",
    "server_name": "CimaNow",
    "server_title": "سيما ناو",
    "icon": `<i class="fas fa-film"></i>`,
    "notification_detected_tobics": ["movies"],
    "get_latest_domain": function () {
        server_title = mou_aflam_server["server_title"];
        server_domain = mou_aflam_server["server_domain"];
        $(".domain_checker .server_name").text(server_title)
        if (typeof local_servers_domains[server_requested] !== "undefined") {
            if (isOnlineUrl(local_servers_domains[server_requested])) {
                server_domain = local_servers_domains[server_requested];
            }
        }
        $.ajax({
            type: "HEAD",
            url: server_domain,
            timeout: 5000,
            success: function (data, textStatus, xhr) {
                domain_found(server_domain);
            },
            error: function (xhr, textStatus, errorThrown) {
                mou_aflam_server["get_prop_domains"](function (domains) {
                    time_out_for_domain = 30;
                    var now_domains_lentgh = domains.length;
                    for (i = 0; i < now_domains_lentgh; i++) {
                        var domain = domains[i];
                        window["get_prop_domain_" + i] = $.ajax({
                            "type": "GET",
                            "url": domain,
                            success: function (domain_res) {
                                doc = new DOMParser().parseFromString(domain_res, "text/html");
                                this_domain_full_url = this.url;
                                active_domain = new URL(this_domain_full_url);
                                active_domain = active_domain.protocol + "//" + active_domain.hostname;
                                if (domain_res.includes("adilbo_HTML_encoder") || $(doc).find("head title").text().trim() == "سيما ناو | عندما يكون للمشاهدة متعة خاصة") {
                                    domain_found(active_domain);
                                    for (let e = 0; e < now_domains_lentgh; e++) {
                                        window["get_prop_domain_" + e].abort();
                                    }
                                }

                            }, error: function (xhr, textStatus, errorThrown) {
                                // console.log(this.url + " => " + xhr.status);
                            }
                        });
                    }
                    setTimeout(function () {
                        for (let e = 0; e < now_domains_lentgh; e++) {
                            window["get_prop_domain_" + e].abort();
                            (".domain_checker_container").show();
                            $(".domain_checker span").html(`<i class="far fa-exclamation-triangle" style="color: #ffc800;"></i> حدث خطأ اثناء الاتصال بسيرفر ` + mou_aflam_server.server_name + `</br><a href="javascript:window.location.href=window.location.href">إعادة التحميل</a>`);
                        }
                    }, time_out_for_domain * 1000)

                });


            }
        });
    },
    "get_prop_domains": function (callback) {
        var g_searsh_key = "cimanow";
        $.ajax({
            "type": "GET",
            "url": "https://www.google.com/search?q=" + g_searsh_key,
            success: function (res) {
                doc = new DOMParser().parseFromString(res, "text/html");
                prop_domains = [];
                $(doc).find(".MjjYud").each(function () {
                    url = $(this).find("a[href]").attr("href");
                    if (isValidUrl(url)) {
                        domain = new URL(url);
                        domain = domain.protocol + "//" + domain.hostname;
                        if (domain.includes(".cimanow.")) {
                            prop_domains.push(domain);
                        }
                    }

                });
                callback(prop_domains);
            }
        })
    },
    start_website: function () {

        if (getQueryVariable("film_url")) {
            qurey_data = get_Queries();
            mou_aflam_server.load_film_function(qurey_data);
        } else {
            $(".header").show();
            $(".server_content").show();
            $(".closer_cats_container hr").hide();
            $("#cats_container").hide();

            $("#custom_selectors").append(`<button class="custom_cat" data-url="الاحدث/">احدث الاضافات</button>`);
            $("#custom_selectors").append(`<button class="custom_cat" data-url="category/رمضان/رمضان-2024/">رمضان 2024</button>`);
            $("#custom_selectors").append(`<button class="custom_cat" data-url="/الاكثر-مشاهدة">الأكثر مشاهدة</button>`);
            $("#custom_selectors").append(`<button class="custom_cat" data-url="category/مسلسلات-عربية/">مسلسلات عربية</button>`);
            $("#custom_selectors").append(`<button class="custom_cat" data-url="category/مسلسلات-اجنبية/">مسلسلات اجنبية</button>`);
            $("#custom_selectors").append(`<button class="custom_cat" data-url="category/مسلسلات-تركية/">مسلسلات تركية</button>`);
            $("#custom_selectors").append(`<button class="custom_cat" data-url="category/افلام-عربية/">افلام عربية</button>`);
            $("#custom_selectors").append(`<button class="custom_cat" data-url="category/افلام-اجنبية/">افلام اجنبية</button>`);
            $("#custom_selectors").append(`<button class="custom_cat" data-url="category/افلام-تركية/">افلام تركية</button>`);
            $("#custom_selectors").append(`<button class="custom_cat" data-url="category/افلام-هندية/">افلام هندية</button>`);
            $("#custom_selectors").append(`<button class="custom_cat" data-url="category/البرامج-التلفزيونية/">البرامج التلفزيونية</button>`);
            $("#custom_selectors").append(`<button class="custom_cat" data-url="category/مسرحيات/">مسرحيات</button>`);

            $(document).on("click", ".custom_cat", function () {
                if (!$(this).hasClass("disabled")) {
                    $(".posts_ul").html("");
                    $(".custom_cat").addClass("disabled");
                    $(this).addClass("loading_elemnt");
                    $(this).removeClass("disabled");

                    $("#load_more_posts_btn").html(`<i class="fad fa-spinner-third fa-spin"></i> جاري التحميل`);


                    this_cat_url = $(this).attr("data-url");
                    this_cat_btn = $(this);
                    $.ajax({
                        "type": "GET",
                        "url": server_domain + this_cat_url,
                        success: function (res) {
                            doc = new DOMParser().parseFromString(res, "text/html");
                            $(".custom_cat").removeClass("disabled").removeClass("active");
                            $(this_cat_btn).addClass("active");
                            $(".custom_cat.loading_elemnt").removeClass("loading_elemnt");
                            mou_aflam_server.load_list_function(res, "first_load");
                        }
                    });

                }
            });
            // $("#load_more_posts_btn").attr("onclick", `mou_aflam_server.get_list_function('movies',this)`).click();

            $("#custom_selectors .custom_cat").eq(0).click();
        }
    }, get_list_function: function (page_url, this_btn) {
        page_url = isValidUrl(page_url) ? page_url : server_domain + page_url;
        disable_attr = $(this_btn).attr('disabled');
        if (loading_more_posts == false) {
            if (!(typeof disable_attr !== 'undefined' && disable_attr !== false)) {
                loading_more_posts = true;
                $(this_btn).html(`<i class="fad fa-spinner-third fa-spin"></i> جاري التحميل`);

                $.ajax({
                    "type": "GET",
                    "url": page_url,
                    success: function (res) {
                        mou_aflam_server.load_list_function(res, "load_more");
                        loading_more_posts = false;

                        $(this_btn).html(`تحميل المزيد`);
                    }
                });
            }

        }
    },
    "load_list_function": function (res, load_type = "first_load") {
        res = mou_aflam_server.get_cima_now_res(res);

        aflam_json = {};
        aflam_posts = [];
        doc = new DOMParser().parseFromString(res, "text/html");

        $(doc).find("section[aria-label='posts']").find("article[aria-label='post']").each(function () {
            film = {};
            $(this).find("li[aria-label='title']").find("em").remove();
            film.url = $(this).find("a[href]").attr("href");
            film.type = $(this).find(`[aria-label="episode"]`).length > 0 || film.url.includes("/selary/") ? "muslsal" : "film";
            film.title = $(this).find("li[aria-label='title']").text().trim();
            film.img = $(this).find("img").attr("data-src");
            if ($(this).find(`[aria-label="episode"]`).length > 0) {
                $(this).find(`[aria-label="episode"] em`).remove();
                film.eposide = parseInt($(this).find(`[aria-label="episode"]`).text().trim().match(/(\d+)/)[0], 10);
            }

            aflam_posts.push(film);
        });
        aflam_json.aflam = aflam_posts;
        next_button = $(doc).find(`ul[aria-label="pagination"] li`).eq(($(doc).find(`ul[aria-label="pagination"] li.active`).index() + 1));
        if (next_button.length > 0) {
            next_page_link = $(next_button).find("a[href]").attr("href");
            aflam_json.next_page = next_page_link;
        }

        load_aflam_posts(aflam_json, load_type);
    }, search_function: function (key) {
        search_url = "?s=" + key;
        $("#load_more_posts_btn").attr("onclick", `mou_aflam_server.get_list_function('${search_url}',this)`).removeAttr("disabled").show().click();
    },
    load_film_function: function (film) {
        film_title = decodeURIComponent(decodeURIComponent(decodeURIComponent(film.film_title)));
        film_url = decodeURIComponent(decodeURIComponent(decodeURIComponent(decodeURIComponent(film.film_url))));
        film_url = isValidUrl(film_url) ? film_url : server_domain + film_url;
        film_img = decodeURIComponent(film.film_img);

        page_type = film.film_type;
        film_eposide = film.eposide;
        $.ajax({
            "type": "GET",
            "url": film_url,
            success: function (res) {
                res = mou_aflam_server.get_cima_now_res(res);

                film_data = {};
                film_trs = {};
                doc = new DOMParser().parseFromString(res, "text/html");
                film_data.title = film_title;
                film_data.film_type = page_type;


                if (film_img == false || film_img == "" || !isValidUrl(film_img)) {
                    film_data.img = $(doc).find(`meta[property="og:image"]`).attr("content");
                } else {
                    film_data.img = film_img;
                }
                film_data.description = $(doc).find(`section[aria-label="details"]`).find(".tabcontent#details li").eq(0).find("p").text().trim();

                $(doc).find(`section[aria-label="details"]`).find(".tabcontent#details li").eq(0).remove();
                $(doc).find(`section[aria-label="details"]`).find(".tabcontent#details li").each(function () {
                    tr = {};
                    tr_key = $(this).find("strong").text().replace(":", "").trim();
                    $(this).find("strong").remove();
                    tr_val = $(this).text().trim();
                    film_trs[tr_key] = tr_val;
                })
                film_data.trs = film_trs;

                show_film_data(film_data);
                if (page_type == "film") {
                    mou_aflam_server.load_msadr_watch(film_url, "film");
                } else if (page_type == "muslsal") {

                    $("#moasm_elmoslsal_container").show();
                    moasm_num = $(doc).find(`section[aria-label="seasons"] ul li`).length;
                    $("#moasm_num").text(` ( ${moasm_num} ) `);


                    // if (film_eposide !== "" && typeof film_eposide !== "undefined") {

                    // $(`#moasm_elmoslsal .mou_eps_num[data-7alkat_link="${active_mosem_link}"]`).click();
                    if (getQueryVariable("halka_num") !== false) {
                        halka_num = getQueryVariable("halka_num");
                        check_7alakat_loded = setInterval(function () {
                            if ($("#hlakat_elmoslsal .mou_eps_num").length > 0) {
                                $("#hlakat_elmoslsal .mou_eps_num").each(function () {
                                    if ($(this).find("em").text() == halka_num) {
                                        $(this).click();
                                    }
                                });
                                clearInterval(check_7alakat_loded);
                            }
                        }, 100);
                    }

                    // check_7alakat_loded = setInterval(function () {
                    //     if ($("#hlakat_elmoslsal .mou_eps_num").length > 0) {
                    //         $("#hlakat_elmoslsal .mou_eps_num").each(function () {
                    //             if ($(this).find("em").text() == film_eposide) {
                    //                 $(this).click();
                    //             }
                    //         });
                    //         clearInterval(check_7alakat_loded);
                    //     }
                    // }, 100);
                    // }


                    $(doc).find(`section[aria-label="seasons"] ul li`).each(function () {
                        $(this).find("a em").remove();
                        mosem_num = $(this).find("a").text().trim().match(/(\d+)/)[0];
                        epo_link = $(this).find("a").attr("href");
                        $("#moasm_elmoslsal").append(`<a class="mou_eps_num" data-7alkat_link="${epo_link}" onclick="mou_aflam_server.load_7alakat_function(this)" data-mosem_num="${mosem_num}"><em>${mosem_num}</em><span>موسم</span></a>`);

                        if ($(this).hasClass("active")) {
                            active_mosem_link = epo_link;
                        }
                    });
                    if (!$(`#moasm_elmoslsal .mou_eps_num[data-7alkat_link="${active_mosem_link}"]`).hasClass("activee")) {
                        $(`#moasm_elmoslsal .mou_eps_num[data-7alkat_link="${active_mosem_link}"]`).addClass("activee");
                    }
                    if (film_eposide !== "" && typeof film_eposide !== "undefined") {
                        $(`#moasm_elmoslsal .mou_eps_num[data-7alkat_link="${active_mosem_link}"]`).click();
                        check_7alakat_loded = setInterval(function () {
                            if ($("#hlakat_elmoslsal .mou_eps_num").length > 0) {
                                $("#hlakat_elmoslsal .mou_eps_num").each(function () {
                                    if ($(this).find("em").text() == film_eposide) {
                                        $(this).click();
                                    }
                                });
                                clearInterval(check_7alakat_loded);
                            }
                        }, 100);
                    }

                    halkat_num = $(doc).find(`#eps li`).length;
                    $("#eposids_num").text(` ( ${halkat_num} ) `);
                    $(doc).find(`#eps li`).each(function () {
                        halka_num = parseInt($(this).find("em").text().trim().match(/(\d+)/)[0], 10);
                        epo_link = $(this).find("a").attr("href");
                        $("#hlakat_elmoslsal").append(`<a class="mou_eps_num" onclick="mou_aflam_server.load_msadr_watch('${epo_link}','muslsal',this)" data-halka_num="${halka_num}"><em>${halka_num}</em><span>حلقة</span></a>`);
                    });
                    $("#hlakat_elmoslsal_container").show();


                    if (getQueryVariable("mosem_num") !== false) {
                        mosem_num = getQueryVariable("mosem_num");
                        $(`[data-mosem_num="${mosem_num}"]`).click();
                    }
                    // if (getQueryVariable("halka_num") !== false) {
                    //     halka_num = getQueryVariable("halka_num");
                    //     $(`[data-halka_num="${halka_num}"]`).click();
                    // }
                }

            }
        });


    },
    load_7alakat_function: function (this_btn) {
        link = $(this_btn).attr("data-7alkat_link");
        $("#moasm_elmoslsal .mou_eps_num").removeClass("activee");
        $(this_btn).addClass("activee");
        // $("#hlakat_elmoslsal").html(`<span><i class="fas fa-circle-notch fa-spin fa-lg"></i> جاري التحميل</span>`);
        $("#hlakat_elmoslsal").html("");

        $.ajax({
            "type": "GET",
            "url": link,
            success: function (res) {
                res = mou_aflam_server.get_cima_now_res(res);
                doc = new DOMParser().parseFromString(res, "text/html");

                halkat_num = $(doc).find(`#eps li`).length;

                $("#eposids_num").text(` ( ${halkat_num} ) `);

                $(doc).find(`#eps li`).each(function () {
                    halka_num = parseInt($(this).find("em").text().trim().match(/(\d+)/)[0], 10);
                    epo_link = $(this).find("a").attr("href");

                    $("#hlakat_elmoslsal").append(`<a class="mou_eps_num" onclick="mou_aflam_server.load_msadr_watch('${epo_link}','muslsal',this)" data-halka_num="${halka_num}"><em>${halka_num}</em><span>حلقة</span></a>`);
                });

            }
        })
    }, load_cimanow_watch_server: function (link, isDownload = false, this_btn = false) {
        // $(`<span class="mou_btn watch_btn" onclick="play_vid(\`${src_link}\`,\`${full_title}\`,\`Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Safari/537.36\`, \`{'Referer':'https://watch26.cimanow.net/'}\`)">${src_name}</span>`).appendTo(".watch_srces_btns");

        // $(".dl_srces_btns").append(`<span class="mou_btn download_btn" onclick="add_for_downlaod(\`downloads/\`,\`${full_title}\`, false, \`${src_link}\`,\`video\`, \`{'Referer':'https://watch26.cimanow.net/'}\`)">${src_name}</span>`);

        this_halka_text = $("#hlakat_elmoslsal .mou_eps_num.activee ,#hlakat_elmoslsal .mou_eps_num.loading").length > 0 ? " الحلقة " + $("#hlakat_elmoslsal .mou_eps_num.activee ,#hlakat_elmoslsal .mou_eps_num.loading").find("em").text() : "";
        continue_watch_code = film_data.title + (film_data.film_type == "film" ? "" : this_halka_text);


        if (isValidUrl(link)) {

            link_ext = get_url_extension(link);
            if (link_ext == "mp4") {
                if (isDownload == false) {
                    full_title = $(this_btn).attr("data-full_title");
                    play_vid(src_link, `${full_title}`, `Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Safari/537.36`, `{'Referer':'${server_domain}'}`, continue_watch_code);
                } else {
                    add_for_downlaod(`downloads/`, full_title, false, src_link, `video`, `{'Referer':'${server_domain}'}`);
                }

            } else {
                $(this_btn).addClass("loading_elemnt");
                dummy_link = new URL(link);
                if (dummy_link.host == "vk.com") {
                    $.ajax({
                        "type": "GET",
                        "url": link,
                        success: function (res) {
                            doc = new DOMParser().parseFromString(res, "text/html");
                            $(this_btn).removeClass("loading_elemnt");

                            watch_link = $(doc).find(".docs_no_preview_download_btn_container").find("a[href]").attr("href");

                            if (isDownload == false) {
                                full_title = $(this_btn).attr("data-full_title");
                                play_vid(watch_link, `${full_title}`, `Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Safari/537.36`, `{'Referer':'${server_domain}'}`, continue_watch_code);
                            } else {
                                add_for_downlaod(`downloads/`, full_title, false, watch_link, `video`, `{'Referer':'${server_domain}'}`);
                            }

                        }
                    });


                } else {
                    console.log(link);
                }



            }

        }

    }, load_msadr_watch: function (link, watch_type, this_btn = false) {
        $(".watch_srces_btns").html("");
        $(".dl_srces_btns").html("");
        $(".loading_watch_srces").show();


        if (this_btn !== false) {
            $("#hlakat_elmoslsal .mou_eps_num").removeClass("activee");
            $(this_btn).addClass("activee");

            halka_num = $(this_btn).find("em").text().trim();
            mosem_num = $("#moasm_elmoslsal .mou_eps_num.activee").find("em").text().trim();
            now_query_data = get_Queries(2, "?" + query_data);
            now_query_data["mosem_num"] = mosem_num;
            now_query_data["halka_num"] = halka_num;
            query_data = encodeQueryData(now_query_data);

            $(".mou_watch_btn").click();
        }
        // if (this_btn !== false) {

        //     $(this_btn).addClass("activee");
        //     halka_num = $(this_btn).find("em").text().trim();
        //     now_query_data = get_Queries(2, "?" + query_data);
        //     now_query_data["halka_num"] = halka_num;
        //     query_data = encodeQueryData(now_query_data);
        // }

        if (typeof loading_msadr_ajax !== "undefined" && loading_msadr_ajax !== false) {
            loading_msadr_ajax.abort();
        }

        loading_msadr_ajax = $.ajax({
            "type": "GET",
            "url": link + "watching/",
            success: function (watching_res) {
                watching_res = mou_aflam_server.get_cima_now_res(watching_res);

                $(".watch_sources span.loading_span,.download_sources span.loading_span").remove();
                watching_doc = new DOMParser().parseFromString(watching_res, "text/html");
                msdr_num = 1;

                // if ($(watching_doc).find(`li[aria-label="quality"]`).length > 1) {
                //     qualities_div = $(watching_doc).find(`li[aria-label="quality"]`).eq(1);
                // } else {
                //     qualities_div = $(watching_doc).find(`li[aria-label="quality"]`).eq(0);
                // }

                $(watching_doc).find(`li[aria-label="quality"]`).each(function () {
                    will_change_src_num = false;
                    $(this).find(`a[href]`).each(function () {

                        src_link = $(this).attr("href");
                        $(this).find("p").remove();
                        quality_name = $(this).text().trim();
                        src_name = "مصدر " + msdr_num + " - " + quality_name;
                        add_to_title = watch_type == "muslsal" ? " - موسم " + $("#moasm_elmoslsal .mou_eps_num.activee em").text() : "";
                        add_to_title += watch_type == "muslsal" ? " - حلقة " + $("#hlakat_elmoslsal .mou_eps_num.activee em").text() : "";
                        full_title = film_data.title + add_to_title + " - " + src_name;


                        add_source_stats = false;
                        if (get_url_extension(src_link) == "mp4") {
                            add_source_stats = true;
                        } else {
                            dummy_link = new URL(src_link);
                            if (dummy_link.host == "vk.com") {
                                add_source_stats = true;
                            }
                        }

                        if (add_source_stats == true) {
                            $(`<span class="mou_btn watch_btn" data-full_title="${full_title}" onclick="mou_aflam_server.load_cimanow_watch_server('${src_link}',false,this)">${src_name}</span>`).appendTo(".watch_srces_btns");

                            $(".dl_srces_btns").append(`<span class="mou_btn download_btn" onclick="add_for_downlaod(\`downloads/\`,\`${full_title}\`, false, \`${src_link}\`,\`video\`, \`{'Referer':'https://watch26.cimanow.net/'}\`)">${src_name}</span>`);
                            will_change_src_num = true;
                        }

                        // $(`<span class="mou_btn watch_btn" onclick="play_vid(\`${src_link}\`,\`${full_title}\`,\`Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Safari/537.36\`, \`{'Referer':'https://watch26.cimanow.net/'}\`)">${src_name}</span>`).appendTo(".watch_srces_btns");

                        // $(".dl_srces_btns").append(`<span class="mou_btn download_btn" onclick="add_for_downlaod(\`downloads/\`,\`${full_title}\`, false, \`${src_link}\`,\`video\`, \`{'Referer':'https://watch26.cimanow.net/'}\`)">${src_name}</span>`);


                    });
                    if (will_change_src_num == true) {
                        msdr_num++;
                    }
                })


                $(".loading_watch_srces").hide();

            }
        })

    }, get_cima_now_res: function (res) {

        if (res.includes("adilbo_HTML_encoder")) {
            enc_script = /<script.*?>(.*\);)/gs.exec(res)[1];
            enc_script = enc_script.replace(/document\[.*/gs, "");
            enc_var_name = /(adilbo_HTML_encoder_.*)='/gm.exec(enc_script)[1].trim();
            script = $(`<script data-id='${enc_var_name}'>`);
            $(script).text(enc_script);
            $("body").append(script);
            res = decodeURIComponent(escape(window[enc_var_name]))
            $(script).remove();
        }
        return res;
    }
};

mou_aflam_servers_array["CimaNow"] = obj;