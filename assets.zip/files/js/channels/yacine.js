obj = {
    "server_name": "yacine",
    "server_title": "سيرفر 1",
    "server_domain": "http://a501.variety-buy.store",
    "working_state": true,
    "icon": `<i class="fas fa-tv"></i>`,
    "get_res": function (url = false, cat_load_type = "cats", from_action = "channels_page", callback) {
        if (url == false) {
            url = "/api/categories";
        } else {
            if (cat_load_type == "cats") {
                url = "/api/categories/" + url;
            } else if (cat_load_type == "channels") {
                if (from_action !== "search") {
                    url = "/api/categories/" + url + "/channels";
                }
            }
        }
        if (typeof window.channels_req !== "undefined") {
            channels_req.abort();
        }
        if (cat_load_type == "cats") {
            now_channels_server.get_cats(url, function (ret) {
                callback(ret);
            });

        } else if (cat_load_type == "channels") {
            now_channels_server.get_channels(url, function (ret) {
                callback(ret);
            });
        }
    },
    "get_cats": function (url, callback) {
        ret = {};
        ret["type"] = "cats";
        ret["cats"] = [];
        // if (typeof window.channels_req !== "undefined") {
        //     channels_req.abort();
        // }
        $.MouAjax({
            type: "GET",
            url: now_channels_server.server_domain + url,
            headers: {
                "Accept": "application/json",
                "User-Agent": "okhttp/3.14.9"
            },
            success: function (res, headers) {

                headers = fix_Res_headers(headers);
                key = "c!xZj+N9&G@Ev@vw" + headers["t"];
                decrypted = JSON.parse(convert_byte_to_string(mouscripts.decrypt_yacine(res, key)));

                for (i = 0; i < decrypted.data.length; i++) {
                    this_cat = decrypted.data[i];
                    cat = {};
                    cat["name"] = this_cat.name;

                    if (typeof this_cat["child_count"] !== "undefined" && parseInt(this_cat["child_count"]) > 0) {
                        cat["load_type"] = "cats";
                    } else {
                        cat["load_type"] = "channels";

                    }
                    cat["url"] = this_cat.id;
                    ret["cats"].push(cat);
                }
                callback(ret);

            }
        })



    }, "get_channels": function (url, callback) {
        ret = {};
        ret["type"] = "channels";
        ret["channels"] = [];

        $.MouAjax({
            type: "GET",
            url: now_channels_server.server_domain + url,
            headers: {
                "Accept": "application/json",
                "User-Agent": "okhttp/3.14.9"
            },
            success: function (res, headers) {
                headers = fix_Res_headers(headers);
                key = "c!xZj+N9&G@Ev@vw" + headers["t"];

                decrypted = JSON.parse(convert_byte_to_string(mouscripts.decrypt_yacine(res, key)));

                for (i = 0; i < decrypted.data.length; i++) {
                    this_channel = decrypted.data[i];
                    channel = {};
                    channel["id"] = this_channel["id"];
                    channel["name"] = this_channel["name"];
                    channel["url"] = this_channel["id"];
                    channel["logo"] = this_channel["logo"];;
                    ret["channels"].push(channel);
                }
                callback(ret);
            }
        })

    },
    "get_channel_srcs": function (ch_name, ch_id = false, callback) {
        ret = {};
        ret["type"] = "srcs";
        ret["srcs"] = [];

        $.MouAjax({
            type: "GET",
            url: now_channels_server.server_domain + "/api/channel/" + ch_id,
            headers: {
                "Accept": "application/json",
                "User-Agent": "okhttp/3.14.9"
            },
            success: function (res, headers) {
                headers = fix_Res_headers(headers);
                key = "c!xZj+N9&G@Ev@vw" + headers["t"];
                decrypted = JSON.parse(convert_byte_to_string(mouscripts.decrypt_yacine(res, key)));
                for (i = 0; i < decrypted.data.length; i++) {
                    this_src = decrypted.data[i];
                    src = {};
                    src["name"] = this_src["name"];
                    src["data"] = {};
                    // src["data"]["name"] = ch_name + " - " + src["name"];
                    src["data"]["name"] = ch_name;
                    src["data"]["url"] = this_src["url"];
                    src["data"]["headers"] = mou_custom_encode(JSON.stringify(this_src["headers"]));
                    ret["srcs"].push(src);
                }
                callback(ret);
            }
        })

    }, "play_src": async function (data, callback) {

        data = JSON.parse(mou_custom_decode(data));

        source_name = data["name"];
        // source_name = "";
        source_link = data["url"];
        source_headers = JSON.parse(mou_custom_decode(data["headers"]));
        user_agent = typeof source_headers["User-Agent"] !== "undefined" ? source_headers["User-Agent"] : "";

        play_vid(source_link, source_name, user_agent, JSON.stringify(source_headers));

        callback();

    }, search_url: function (search_key) {
        search_url = `/api/search?query=` + search_key;
        return search_url;
        // now_channels_server.get_channels(search_url, function (ret) {
        //     callback(ret);
        // });

    }
};
mou_channels_servers["yacin"] = obj;