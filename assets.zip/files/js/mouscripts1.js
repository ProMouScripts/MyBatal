function get_vk_url(url, callback) {
    $.ajax({
        "type": "GET",
        "url": url,
        success: function (res) {
            hls_url = null;
            if (/hls":"(.*?)"/m.test(res)) {
                hls_url = /hls":"(.*?)"/m.exec(res)[1].replace(/\\(.)/mg, "$1");
                callback(hls_url);
            }
            // console.log("hls_url => " + hls_url + "\n" + "mouscripts.get_vk_src() => " + mouscripts.get_vk_src());
        }
    });
}